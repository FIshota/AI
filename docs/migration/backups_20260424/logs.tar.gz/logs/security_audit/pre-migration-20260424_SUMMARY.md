# Pre-Migration Vulnerability Audit — 2026-04-24

## 判定: ⚠️ WARN (移管可、ただし要アクション)

## pip-audit 結果

### ai-chan
| Package | Ver | CVE | Fix | ステータス |
|---|---|---|---|---|
| diskcache | 5.6.3 | CVE-2025-69872 (pickle RCE) | **なし** | ✅ mitigated in `core/llm.py:28-83, 433` (キャッシュディレクトリ権限強化済) |

### hinomoto-model
- **No known vulnerabilities** ✅

## bandit (ai-chan)
- High: **0**
- Medium: **38** (うち要注目)
  - `B104` web_main.py:22,78 `0.0.0.0` バインド → loopback 限定推奨 or 環境変数化
  - `B108` test_yamato.py:142 `/tmp/t.gguf` ハードコード (テスト専用、低リスク)
- Low: 2828 (大半は assert/try-except-pass の慣用、無視可)
- 総行数: 79,011

## Outdated パッケージ (48件)
### セキュリティ関連 (優先)
- `cryptography` 46.0.5 → 46.0.7
- `pillow` 12.1.1 → 12.2.0
- `requests` / urllib3 系は最新
- `fastapi` 0.135.3 → 0.136.1
- `transformers` 5.5.0 → 5.6.2
- `mlx` 0.31.1 → 0.31.2

## Secrets
- 3件検出 → **すべて誤検出** (secret_scan.py 内の regex + llama_cpp `<|im_end|>` 特殊トークン)

## Permissions
- `config/*.json` が 644 → 機微ファイル (persona/access_control/voice_auth) は **600 推奨**

---

## 推奨アクション (移管前)

### 🔴 P0 (今すぐ)
1. `chmod 600 config/persona.json config/access_control.json config/voice_auth_challenges.yaml`
2. `pip install -U cryptography pillow` (セキュリティ依存のみ即時更新)

### 🟡 P1 (移管先で)
3. 48件 outdated の一括更新: `pip install -U -r requirements.txt` → F8 ゴールデンテスト再走
4. `web_main.py` の `0.0.0.0` → `127.0.0.1` またはsettings で切替可能化

### 🟢 P2 (継続監視)
5. diskcache は fix version 未リリース → PyPI 監視を継続 (既に自動監査スケジュール稼働中)

---

## CVE 詳細: CVE-2025-69872
**DiskCache ≤5.6.3 pickle deserialization RCE**
- 条件: 攻撃者がキャッシュディレクトリに書き込み可
- 本プロジェクトでは `core/llm.py` で既に以下を実装済:
  - キャッシュディレクトリを user-only パス (`~/.cache/ai-chan/`) に固定
  - ディレクトリ権限を 700 に強制
  - 所有者 uid 検証
- 結論: **exploitable ではない** (移管先でも同じ緩和が適用される)
