# Backup-Restore Drills

## 目的

ai-chan の記憶 (暗号化 SQLite: `memories.db` / `emotion_history.db` / `diary.db`)
と記念日 (`anniversaries/*.json`)、personality / config を
**「壊れた時に確実に救出できるか」** を月次で実装レベル検証する。

バックアップが「取れている」ことと「戻せる」ことは別問題なので、
人手 review より先に自動ドリルが検知できる状態を維持する。

## 実行

```bash
bash scripts/backup_restore_drill.sh
```

自動化は `launchd/com.aichan.backup-restore-drill.plist` (毎月 15 日 3:30 JST)。
Kill-Switch drill (毎月 1 日) から 2 週間ずらしてある。

## ドリルのフロー

| Phase | 内容 |
|---|---|
| 1 | sandbox に dummy `data/`, `personality/`, `config/` をシード (memories.db / emotion_history.db / diary.db / anniversaries/*.json 等) |
| 2 | `core.backup_rotator.BackupRotator.create_backup` で backup を作成 (importable でない場合は `tar -czf` フォールバック) |
| 3 | backup 以外の state を全削除 |
| 4 | `restore_backup(backup_name)` で復旧 (フォールバック時は `tar -xzf`) |
| 5 | sha256 manifest を取って元と byte-for-byte 一致・ファイル数一致を検証 |

## 結果ファイル

- `PASS-YYYYMMDD_HHMMSS.md` — 成功
- `FAILED-YYYYMMDD_HHMMSS.md` — 失敗 (復旧契約違反の可能性)

## ドリル v0 の既知の限界

- 実ファイルは **dummy bytes** であり、本物の暗号化 SQLite (鍵回転込み) での
  round-trip は検証していない。鍵 (`.key`) は `BackupRotator` が除外するため、
  「別環境への復旧」シナリオは現状カバー外。
- `create_backup` は内部で `pre_restore` バックアップを追加生成するため、
  Phase 5 の比較では `backups/` ディレクトリを除外している。この除外ロジックが
  実装側変更で崩れると false pass のリスクあり。
- Fallback の `tar` パスは、実装の除外ルール (`__pycache__`, `.DS_Store`,
  `*.pyc`, `.key` 等) を再現しない。実装モジュールが import できる前提で運用する。
- ディスク破損・途中書き込みシナリオ (fsync / crash consistency) は未検証。

## 次のドリル改善項目

- [ ] sandbox で `sqlite3` と実スキーマを使って実データ (INSERT 済み) を作り、
      backup → restore 後に `SELECT COUNT(*)` が一致することを検証する
- [ ] anniversaries の実ファイル命名・schema に合わせる
- [ ] 鍵ローテ後 (古い `.key` 破棄) に「古いバックアップ」を復旧できないことを
      明示的に検証 (負の契約: 忘却保証)
- [ ] 部分破損シナリオ: backup tar.gz の後半数 KB を zero-fill して
      restore が **検知して止まる** ことを確認
- [ ] 別 host (`hostname` が異なる) で復旧可能かを別ドリルで確認

## 月次チェックリスト

| 日付 | PASS/FAIL | backup_mode | コメント |
|---|---|---|---|
| — | — | — | 初回実行待ち |
