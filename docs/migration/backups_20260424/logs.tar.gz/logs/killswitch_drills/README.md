# Kill-Switch Drills

## 目的

`VALUES.md` の「消す権利」が **実装で守られているか** を月次で検証する。
人手 review より先に自動ドリルが検知できる状態を維持する。

## 実行

```bash
bash scripts/killswitch_drill.sh
```

自動化は `launchd/com.aichan.killswitch-drill.plist` (毎月 1 日 3:00 JST)。

## 結果ファイル

- `PASS-YYYYMMDD_HHMMSS.md` — 成功
- `FAILED-YYYYMMDD_HHMMSS.md` — 失敗 (契約違反の可能性)

## ドリル v0 の既知の限界

**2026-04-23 初回ドリルで判明**:

`SubjectRightsManager.purge_subject` は **SQL スキーマ単位** で動作するため、
sandbox に単純にダミー `.db` / `.json` を配置しただけでは `rows_deleted=0` で
終わる。これは「purge が動いていない」のではなく「ドリルのシード形式が
実装と合っていない」。

### 次のドリル改善項目 (次回更新まで)

- [ ] sandbox にまず実 schema で `memories.db` / `emotion_history.db` を
      `sqlite3` で作成 → INSERT で dummy row 投入 → purge → `SELECT COUNT(*)==0` 検証
- [ ] anniversaries は JSON ディレクトリに実装通りの命名で書き込む
- [ ] `export_subject` も drill に含める (purge の前に export → 出力 JSON
      に PII が **含まれる** ことと、purge 後に再 export すると空 になることの両方を検証)
- [ ] `Kill-Switch 全消し` (アプリ再起動不能状態) の別モード drill を用意

## 月次チェックリスト

| 日付 | PASS/FAIL | コメント |
|---|---|---|
| 2026-04-23 | FAIL (既知限界) | ドリル v0 初回。実装側の purge は動作、ドリル側のシード形式が未整合 |
