# logs/flaky/ — Flaky テスト検出ログ

このディレクトリは `pytest-flakefinder` / `pytest-rerunfailures` によって検出された非決定的テスト (flaky tests) の履歴と registry を保持する。

## ファイル構成

| ファイル | 目的 |
|---------|------|
| `<YYYY-MM-DD>.txt` | `scripts/run_flaky_finder.sh` の生ログ |
| `weekly-<YYYY-MM-DD>-summary.md` | `scripts/run_weekly_flaky.sh` が生成する週次サマリ（Markdown テーブル） |
| `launchd.out` / `launchd.err` | launchd 経由実行時の stdout/stderr |
| `README.md` | 本ファイル。flaky テスト registry を兼ねる |

## 運用

- 検出手順・トリアージフロー: [`docs/quality/FLAKY_TRACKING.md`](../../docs/quality/FLAKY_TRACKING.md)
- スケジュール: 毎週土曜 04:00 JST（launchd）
- 保存期間: 直近 3 ヶ月分（古いログは `logs/archive/` へ移すか削除）

## Flaky テスト Registry（テンプレート）

新規 flaky が発生したら、以下のテンプレートを使ってエントリを追記する。
修正完了したエントリは「status: resolved」として残すこと（再発検知のため）。

### テンプレート

```markdown
### <test path>

- **test path**: `tests/xxx/test_yyy.py::test_zzz`
- **first observed**: YYYY-MM-DD
- **observed count**: N 回（10 runs 中 N 回失敗 等）
- **hypothesis**: 根本原因の仮説（例: 並列実行時の temp file 競合、time.time() 依存、...）
- **owner**: <github handle or name>
- **deadline**: YYYY-MM-DD（初観測 + 2週間）
- **status**: open | in-progress | quarantined | resolved
- **notes**: 調査メモ・関連 issue/PR リンク
```

### 記載例（架空）

```markdown
### tests/test_example_regression.py::test_time_sensitive

- **test path**: `tests/test_example_regression.py::test_time_sensitive`
- **first observed**: 2026-04-22
- **observed count**: 10 runs 中 2 回失敗
- **hypothesis**: `datetime.now()` をモックしておらず、秒境界で off-by-one が発生
- **owner**: ai-chan-core
- **deadline**: 2026-05-06
- **status**: quarantined
- **notes**: `@pytest.mark.flaky` 付与済み。freezegun 導入で解消予定
```

## アクティブ Registry

（現時点で検出済みの flaky テストは無し。最初の検出後にここへ追記する）
